# Clyde Viewings counter

This micro-extension does one thing: it numbers your Clyde Property viewings and gives you a total viewings count. For whatever reason, the (otherwise excellent) Clyde Property system doesn't list this and it can be hard to keep track if you have a lot of viewings.
